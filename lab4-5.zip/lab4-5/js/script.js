const margin = { top: 40, right: 40, bottom: 40, left: 60 };
const width = 600 - margin.left - margin.right;
const height = 400 - margin.top - margin.bottom;

const continents = ['Africa', 'Asia', 'Oceania', 'Americas', 'Europe'];
const colorScale = d3.scaleOrdinal(continents, d3.schemeSet2); // d3.schemeSet2 is a set of predefined colors.
const options = ['income', 'lifeExp', 'gdp', 'population', 'childDeaths'];

const t = 1000;

const varDict = {
    "income": "Income Per Person",
    "lifeExp": "Life Expectancy",
    "gdp": "GDP Per Capita",
    "population": "Population",
    "childDeaths": "Child Deaths"
}; // give better names to the variables

let allData = [];
let xVar = 'income', yVar = 'lifeExp', sizeVar = 'population', targetYear = 2000
let xScale, yScale, sizeScale;

const svg = d3.select('#vis')
    .append('svg')
    .attr('width', width + margin.left + margin.right)
    .attr('height', height + margin.top + margin.bottom)
    .append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`);

function init() {
    d3.csv('./data/gapminder_subset.csv', function (d) {
        return {
            // Besides converting the types, we also simpilify the variable names here. 
            country: d.country,
            continent: d.continent,
            year: +d.year, // using + to convert to numbers; same below
            lifeExp: +d.life_expectancy,
            income: +d.income_per_person,
            gdp: +d.gdp_per_capita,
            childDeaths: +d.number_of_child_deaths,
            population: +d.population
            // Your turn: 
            // convert d.population, and assign it to population
        }
    }).then(data => {
        allData = data;
        setupSelector();
        updateAxes();
        updateVis();
        addLegend();
    })
        .catch(error => console.error('Error loading data:', error));
}

window.addEventListener('load', init);

function setupSelector() {
    d3.select('#value').text(targetYear); // Initialize the slider value display

    let slider = d3
        .sliderHorizontal()
        .min(d3.min(allData.map(d => +d.year))) // setup the range
        .max(d3.max(allData.map(d => +d.year))) // setup the range
        .step(1)
        .width(width * 0.9)  // Widen the slider if needed (the slider was going out of the view, so I did the opposite)
        .displayValue(false)
        .on('onchange', (val) => {
            d3.select('#value').text(val);
            targetYear = +val; // Update the year
            updateVis(); // Refresh the chart
        })
        .default(targetYear);

    d3.select('#slider')
        .append('svg')
        .attr('width', width)  // Adjust width if needed
        .attr('height', 100)
        .append('g')
        .attr('transform', 'translate(30,30)')
        .call(slider);

    d3.selectAll('.variable')
        // loop over each dropdown button
        .each(function () {
            d3.select(this).selectAll('myOptions')
                .data(options)
                .enter()
                .append('option')
                .text(d => varDict[d]) // The displayed text
                .attr("value", d => d) // The actual value used in the code
        });

    d3.select('#xVariable').property('value', xVar)
    d3.select('#yVariable').property('value', yVar)
    d3.select('#sizeVariable').property('value', sizeVar)

    d3.selectAll('.variable')
        .each(function () {
        })
        .on("change", function (event) {
            if (d3.select(this).property("id") == "xVariable") {
                xVar = d3.select(this).property("value");
            }

            if (d3.select(this).property("id") == "yVariable") {
                yVar = d3.select(this).property("value");
            }

            if (d3.select(this).property("id") == "sizeVariable") {
                sizeVar = d3.select(this).property("value");
            }
            updateAxes();
            updateVis();
        })
}

function updateAxes() {
    svg.selectAll('.axis').remove()
    svg.selectAll('.labels').remove()

    xScale = d3.scaleLinear()
        .domain([0, d3.max(allData, d => d[xVar])])
        .range([0, width]);
    const xAxis = d3.axisBottom(xScale)
        .ticks(6) // Do not use too many ticks
        .tickFormat((d, i) => {
            return d3.format(".6~g")(d); // Do not write very large numbers out
        });

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(0,${height})`) // Position at the bottom
        .call(xAxis);

    yScale = d3.scaleLinear()
        .domain([0, d3.max(allData, d => d[yVar])])
        .range([height, 0]);
    const yAxis = d3.axisLeft(yScale).tickFormat((d, i) => {
            return d3.format(".6~g")(d); // Do not write very large numbers out
        });;

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(0,0)`) // Position on the left
        .call(yAxis);

    // X-axis label
    svg.append("text")
        .attr("x", width / 2)
        .attr("y", height + margin.bottom - 5) // added some extra padding
        .attr("text-anchor", "middle")
        .text(varDict[xVar]) // Displays the current x-axis variable
        .attr('class', 'labels')

    // Y-axis label
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", -margin.left + 20) // added some extra padding
        .attr("text-anchor", "middle")
        .text(varDict[yVar]) // Displays the current y-axis variable
        .attr('class', 'labels');

    sizeScale = d3.scaleSqrt()
        .domain([0, d3.max(allData, d => d[sizeVar])]) // Largest bubble = largest data point 
        .range([5, 20]); // Feel free to tweak these values if you want bigger or smaller bubbles
}

function updateVis() {
    let currentData = allData.filter(d => d.year === targetYear)
    svg.selectAll('.points')
        .data(currentData, d => d.country)
        .join(
            function (enter) {
                return enter
                    .append('circle')
                    .attr('class', 'points')
                    .attr('cx', d => xScale(d[xVar])) // Position on x-axis
                    .attr('cy', d => yScale(d[yVar])) // Position on y-axis
                    .style('fill', d => colorScale(d.continent))
                    .style('opacity', .5)  // Default color for now
                    .attr('r', 0) // Bubble size
                    .on('mouseover', function (event, d) {
                        //console.log(d) // See the data point in the console for debugging
                        d3.select('#tooltip')
                            // if you change opacity to hide it, you should also change opacity here
                            .style("display", 'block') // Make the tooltip visible
                            .html( // Change the html content of the <div> directly
                                `<strong>${d.country}</strong><br/>
                Continent: ${d.continent}`)
                            .style("left", (event.pageX + 20) + "px")
                            .style("top", (event.pageY - 28) + "px");
                        d3.select(this) // Refers to the hovered circle
                            .style('stroke', 'black')
                            .style('stroke-width', '2px')
                    })
                    .on("mouseout", function (event, d) {
                        d3.select('#tooltip')
                            .style('display', 'none')
                        d3.select(this)
                            .style('stroke', 'none') // Hide tooltip when cursor leave
                    })
                    .transition(t)
                    .attr('r', d => sizeScale(d[sizeVar])) // Bubble size

            },
            function (update) {
                return update
                    .transition(t)
                    .attr('cx', d => xScale(d[xVar]))
                    .attr('cy', d => yScale(d[yVar]))
                    .attr('r', d => sizeScale(d[sizeVar]))
            },
            function (exit) {
                exit.transition(t)
                    .attr('r', 0)
                    .remove()
            }
        )
}

function addLegend() {
    let size = 10;  // Size of the legend squares

    // Your turn, draw a set of rectangles using D3
    svg.selectAll('continentSquare')
        .data(continents)
        .enter()
        .append("rect")
        .attr("y", -margin.top / 2) // Align vertically with the square
        .attr("x", (d, i) => i * (size + 100) + 100)
        .attr("width", size)
        .attr("height", size)
        .style("fill", d => colorScale(d))  // Match text color to the square
        // data here should be "continents", which we've defined as a global variable
        // the rect's y could be  -margin.top/2, x could be based on i * (size + 100) + 100
        // i is the index in the continents array
        // use "colorScale" to fill them; colorScale is a global variable we defined, used in coloring bubbles
        .style("fill", d => colorScale(d))

    svg.selectAll("continentName")
        .data(continents)
        .enter()
        .append("text")
        .attr("y", -margin.top / 2 + size) // Align vertically with the square
        .attr("x", (d, i) => i * (size + 100) + 120)
        .style("fill", d => colorScale(d))  // Match text color to the square
        .text(d => d) // The actual continent name
        .attr("text-anchor", "left")
        .style('font-size', '13px')

}